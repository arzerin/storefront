// $Id: pwcs_storelocator.js 2012/11/20 rasel kabir Exp $

var map = null;
var marker = null;
var markers = null;
var infowindow = new google.maps.InfoWindow({ size: new google.maps.Size(150,50) });
//var infowindow = new google.maps.InfoWindow();

//Create Store Location Markers, InfoWindow, 
function createStorelocationMarker(latlng, slid, contentString) {

  var marker = new google.maps.Marker({
    position: latlng,
    map: map,
    zIndex: Math.round(latlng.lat()*-100000)<<5
  });

  // Building Cick Event For InfoWindow
  google.maps.event.addListener(marker, 'click', (function(marker, name) {
    return function() {
      infowindow.setContent(contentString);
      infowindow.open(map, marker);
    }
  })(marker, name));
  
  // Building Cick Event For Triggering InfoWindow From External Link
  var external_link = document.getElementById("storelocation_link_"+slid);
  google.maps.event.addDomListener(external_link, "click", function(){
    google.maps.event.trigger(marker, "click");
    map.setZoom(12);
    //map.panTo(marker.position);
  });

  return marker;
}

$(document).ready(function() {

  //Create the map with Center USA
  var lat = 40;
  var lng = -100;
  var mapzoom = 4;
  var mapOptions = {
    zoom: mapzoom,
    center: new google.maps.LatLng(lat, lng),
    mapTypeControl: true,
    mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
    navigationControl: true,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  }
  map = new google.maps.Map(document.getElementById("pwcs_storelocation_map"), mapOptions);

  //Close InfoWindow when clicked on map
  google.maps.event.addListener(map, 'click', function() {
    infowindow.close();
  });

  var latlngbounds = new google.maps.LatLngBounds();
  //Set All Locations Marker
  $('a.storelocation_link').each(function(){
    var slid = $(this).attr('slid');
    var lat = $(this).attr('lat');
    var lng = $(this).attr('lng');
    var latLng = new google.maps.LatLng(lat, lng);
    var contentString = $(this).attr('tooltip_html');
    createStorelocationMarker(latLng, slid, contentString);
    latlngbounds.extend(latLng);
  });
  map.fitBounds(latlngbounds);
  //map.setZoom(1);
  var listener = google.maps.event.addListener(map, "idle", function() { 
    if (map.getZoom() > 12) map.setZoom(12); 
    google.maps.event.removeListener(listener); 
  });

  $('.storelocation_link').click(function(e) {
    e.preventDefault();
    $('.storelocation_link').removeClass('active');
    $(this).addClass('active');
  });

});

