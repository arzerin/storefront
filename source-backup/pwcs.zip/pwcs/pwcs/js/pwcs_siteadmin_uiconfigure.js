$(document).ready(function() {

  var windowwidth = $(window).width() - 2;
  var windowheight = $(window).height() - 55;
  $('.uiconfigure_page').width(windowwidth+'px');
  $('.uiconfigure_page').height(windowheight+'px');

  $('.uiconfigure_page iframe').height('0%');
  $('.uiconfigure_page').append('<div class="pwcs-loading" style="height: 100%;"></div>');
  $('.uiconfigure_page iframe').load(function() {
    $('.uiconfigure_page').find('.pwcs-loading').remove();
    $('.uiconfigure_page iframe').height('100%');
  });

  $('.uiconfigure_settings .uiconfigure_settings_header .uiconfigtoggle').click(function(e) {
    e.preventDefault();
    $('.uiconfigure_settings .uiconfigure_settings_header .close').fadeIn();
    $($(this).attr('togglecontent')).show();
    $('.uiconfigure_settings input[name=search_widgetblock]').focus();
    $('.uiconfigure_settings_content').slideDown('fast');
    $('.uiconfigure_page').hide();
  });
  $('.uiconfigure_settings .close').click(function(e) {
    e.preventDefault();
    $('.uiconfigure_settings .uiconfigure_settings_header .close').fadeOut();
    $('.settingsitem').hide();
    $('.uiconfigure_settings_content').slideUp('fast');
    $('.uiconfigure_page').show();
  });
  
  $('.uiconfigure_settings select[name=page_selection]').change(function(e) {
    e.preventDefault();
    $('.uiconfigure_page iframe').height('0%');
    $('.uiconfigure_page').append('<div class="pwcs-loading" style="height: 100%;"></div>');
    $('.uiconfigure_page iframe').attr('src', Drupal.settings.basePath+'siteadmin/uiconfigure/getpage/'+$(this).val());
    $('.uiconfigure_page iframe').load(function() {
      $('.uiconfigure_page').find('.pwcs-loading').remove();
      $('.uiconfigure_page iframe').height('100%');
    });
    //window.location.href = Drupal.settings.basePath+'siteadmin/uiconfigure/' + $(this).val();
  });  
  
  $('.uiconfigure_settings input[name=search_widgetblock]').focus().keyup(function() {
    var filterword = $(this).val()
    filterword = filterword.replace('(', '');
    filterword = filterword.replace(')', '');
    filterword = filterword.replace('"', '');
    filterword = filterword.replace('#', '');
    filterword = filterword.replace('$', '');
    $('.managewidgetblock .toggleblock_checkbox label:not(:icontains("' + filterword.toLowerCase() + '"))').parents('.toggleblock_checkbox').fadeOut('slow');
    $('.managewidgetblock .toggleblock_checkbox label:icontains("' + filterword.toLowerCase() + '")').parents('.toggleblock_checkbox').fadeIn('fast');
  });

});
