//$(document).ready(function() {

$(window).load(function() {

  $('a').attr('href', '#');
  $('a').removeAttr('target');

  var config_html = '<div class="pwcs_configure" style="display:none;">'
                   +'<div class="pwcs_configure_inner">'
                   +'<a href="#" class="config_link"><span class="settings"></span>Configure</a>'
                   +'</div>'
                   +'</div>';

  $('.block').children('.inner').append(config_html);

  $('.block .inner .pwcs_configure').each(function() {

    var w = $(this).closest('.block .inner').width();
    $(this).css('width', w+'px');
    var lp = $(this).closest('.block .inner').css('padding-left');
    $(this).css('left', lp);
    var h = $(this).closest('.block .inner').height();
    $(this).css('height', h+'px');
    var tp = $(this).closest('.block .inner').css('padding-top');
    $(this).css('top', tp);

    if(w < 100) {
      $(this).find('a.config_link').html('<span class="settings"></span>');
      $(this).find('a.config_link').addClass('smallblock');
    }

    var configlink = '';
    
    var blockid = $(this).closest('.block').attr('id'); //console.log(blockid);
    console.log('blockid: ' + blockid);

    if(!blockid) {
      // Invalid .block .inner
      //$(this).closest('.block').css('border', '2px solid red');
      //$(this).closest('.block').find('.pwcs_configure').remove();
    }
    else if(blockid == 'content-inner') {
      
      var bodyid = $(this).closest('body').attr('id');
      console.log('bodyid: '+bodyid);
      
      if(bodyid == 'pid-homepage') { // Homepage
        configlink = Drupal.settings.basePath+'advancepages/siteadmin/sitepage?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-products') { //All Products
        configlink = Drupal.settings.basePath+'siteadmin/products?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-manufacturers') { //All Manufacturers
        configlink = Drupal.settings.basePath+'siteadmin/manufacturers?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-contactus') { //Contact Us
        configlink = Drupal.settings.basePath+'advancepages/siteadmin/sitepage?highlighted=contactus&destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-storelocator') { //Store Locator
        configlink = Drupal.settings.basePath+'siteadmin/storelocations?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-photogallery') { //Photo Gallery
        configlink = Drupal.settings.basePath+'siteadmin/photogallery?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-clubfees') { //Club Fees
        configlink = Drupal.settings.basePath+'siteadmin/clubfeeproducts?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-affiliate') { //Affiliate
        configlink = Drupal.settings.basePath+'admin/build/block/configure/pwcs/productmodule_affiliate?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-coaches') { //Coaches
        configlink = Drupal.settings.basePath+'siteadmin/websitebuilder/schedulesystems?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-scheduleevents') { //Events
        configlink = Drupal.settings.basePath+'siteadmin/websitebuilder/schedulesystems?destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-schedulefreetrial') { //Free Trial
        configlink = Drupal.settings.basePath+'advancepages/siteadmin/sitepage/default?highlighted=schedulesystem&destination=siteadmin/uiconfigure';
      }
      else if(bodyid == 'pid-blogs') { //Blogs
        configlink = Drupal.settings.basePath+'siteadmin/blog?destination=siteadmin/uiconfigure';
      }

      if(configlink == '') {
        $(this).find('a.config_link').remove();
      } else {
        $(this).find('a.config_link').attr('href', configlink);
      }
    }
    else if(blockid == 'header-site-info') {
      configlink = Drupal.settings.basePath+'siteadmin/websitebuilder/manageheaderfooter/?tab=site_logo&destination=siteadmin/uiconfigure';
      $(this).find('a.config_link').attr('href', configlink);
    }
    else if((blockid == 'footer-message-text') || (blockid == 'footer-message') || (blockid == 'block-pwcs-site_footer_message')) {
      configlink = Drupal.settings.basePath+'siteadmin/websitebuilder/manageheaderfooter/?tab=site_footer&destination=siteadmin/uiconfigure';
      $(this).find('a.config_link').attr('href', configlink);
    }
    else if(blockid == 'block-menu-primary-links') {
      configlink = Drupal.settings.basePath+'siteadmin/menusettings/primarymenu?destination=siteadmin/uiconfigure';
      $(this).find('a.config_link').attr('href', configlink);
    }
    else if(blockid == 'block-menu-secondary-links') {
      configlink = Drupal.settings.basePath+'siteadmin/menusettings/secondarymenu?destination=siteadmin/uiconfigure';
      $(this).find('a.config_link').attr('href', configlink);
    }
    else if(blockid == 'block-pwcs-image_slideshow') {
      configlink = Drupal.settings.basePath+'siteadmin/manageblocks/imageslideshow/?destination=siteadmin/uiconfigure';
      $(this).find('a.config_link').attr('href', configlink);
    }
    else {
      var blockid_array = blockid.split("-");
      if(blockid_array[0] == 'block') {
        configlink = Drupal.settings.basePath+'admin/build/block/configure/'+blockid_array[1]+'/'+blockid_array[2]+'/?destination=siteadmin/uiconfigure';
        $(this).find('a.config_link').attr('href', configlink);
      } else {
        $(this).find('a.config_link').remove();
      }
    }
    
  });

  $('.block .inner').mouseover(function() {
    $(this).find('.pwcs_configure').show();
  }).mouseout(function(){
    $(this).find('.pwcs_configure').hide();
  });
   
  $('.pwcs_configure a.config_link').click(function(e) {
    e.preventDefault();
    window.top.location.href = $(this).attr('href');
  });

  // Header Banner
  var headerbg_config_html = '<div class="headerbg_config">'
                            +'<div class="headerbg_config_inner">'
                            +'<a href="#" class="headerbg_config_link"><span class="settings"></span>Header Background</a>'
                            +'</div>'
                            +'</div>';
  $('.header-group .header-group-inner').append(headerbg_config_html);
  $('.header-group .header-group-inner .headerbg_config a.headerbg_config_link').attr('href', Drupal.settings.basePath+'siteadmin/websitebuilder/manageheaderfooter/?tab=header_image&destination=siteadmin/uiconfigure');

  $('.headerbg_config .headerbg_config_link').mouseover(function() {
    $('.headerbg_config').animate({ height: "100%" }, 'fast' );
  }).mouseout(function(){
    $('.headerbg_config').animate({ height: "0%" }, 'fast' );
  });
  $('.headerbg_config a.headerbg_config_link').click(function(e) {
    e.preventDefault();
    window.top.location.href = $(this).attr('href');
  });

  // Site Background
  var sitebg_config_html = '<div class="sitebg_config">'
                          +'<div class="sitebg_config_inner">'
                          +'<a href="#" class="sitebg_config_link"><span class="settings"></span>Site Background</a>'
                          +'</div>'
                          +'</div>';
  $('.page .page-inner').append(sitebg_config_html);
  $('.page .page-inner .sitebg_config a.sitebg_config_link').attr('href', Drupal.settings.basePath+'siteadmin/websitebuilder/manageheaderfooter/?tab=site_background&destination=siteadmin/uiconfigure');

  var current_sitebg = $('.page .page-inner').css('background');
  $('.sitebg_config a.sitebg_config_link').mouseover(function() {
    $('.page .page-inner').css('background', 'url('+Drupal.settings.basePath+'sites/all/modules/pwcs/images/uiconfigure/sitebg.jpg) center center repeat scroll transparent');
  }).mouseout(function(){
    $('.page .page-inner').css('background', current_sitebg);
  });
  $('.sitebg_config a.sitebg_config_link').click(function(e) {
    e.preventDefault();
    window.top.location.href = $(this).attr('href');
  });  


});
