// $Id: pwcs_storelocator.js 2012/11/20 rasel kabir Exp $

var map = null;
var marker = null;
var infowindow = new google.maps.InfoWindow({ size: new google.maps.Size(150,50) });

// A function to create the marker and set up the event window function 
function createMarker(latlng, name, html) {

  var contentString = html;
  var marker = new google.maps.Marker({
      position: latlng,
      map: map,
      zIndex: Math.round(latlng.lat()*-100000)<<5
  });

  google.maps.event.addListener(marker, 'click', function() {
      infowindow.setContent(contentString); 
      infowindow.open(map,marker);
  });
  google.maps.event.trigger(marker, 'click');
  return marker;
}

$(document).ready(function() {

  var slid = $('#edit-slid').val();
  if(slid>0) {
    var lat = $('#edit-latitude').val();
    var lng = $('#edit-longitude').val();
    var mapzoom = 8;
  } else {
    // Center USA
    var lat = 40;
    var lng = -100;
    var mapzoom = 3;
  }

  //Create the map
  var mapOptions = {
    zoom: mapzoom,
    center: new google.maps.LatLng(lat, lng),
    mapTypeControl: true,
    mapTypeControlOptions: {style: google.maps.MapTypeControlStyle.DROPDOWN_MENU},
    navigationControl: true,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  }
  map = new google.maps.Map(document.getElementById("pwcs_storelocation_form_map"), mapOptions);

  //Remove Infowindow on click on map
  google.maps.event.addListener(map, 'click', function() {
    infowindow.close();
  });

  //Set Marker in Store Location Edit/Update Mode 
  var slid = $('#edit-slid').val();
  if(slid>0) {
    var editTitle = $('#edit-title').val();
    var editAddress = $('#edit-address').val();
    var editLat = $('#edit-latitude').val();
    var editLng = $('#edit-longitude').val();
    var editLatLng = new google.maps.LatLng(editLat, editLng);
    marker = createMarker(editLatLng, "storelocation", "<b>"+editTitle+"</b><br>"+editAddress);
  } 

  //Click on Map event
  google.maps.event.addListener(map, 'click', function(event) {

    //call function to create marker
    if (marker) {
      marker.setMap(null);
      marker = null;
    }
    var title = $('#edit-title').val();
    var address = $('#edit-address').val();
    title = (title == '') ? 'Store Location' : title;
    address = (address == '') ? 'Address Not Defined' : address;
    var html = "<b>"+title+"</b><br>"+address;
    marker = createMarker(event.latLng, "storelocation", html);

    //Set Lat/Lng to hidden form field
    $('#edit-latitude').val(event.latLng.lat());
    $('#edit-longitude').val(event.latLng.lng());

    //Stop Auto Focus
    $('#autofind_location').attr("checked", false);
    $('.address-result').hide();

  });

  //Address Search
  $('#edit-address').keyup(function() {
    
    if ($('#autofind_location').attr("checked") == true) {

      var currentaddress = $(this).val();
      $('.address-result').html(currentaddress);
      
      var geocoder = new google.maps.Geocoder();
      geocoder.geocode( { 'address': currentaddress, 'partialmatch': true }, function(results, status) {
        if (status == 'OK' && results.length > 0) {
          $('.address-result').html('<span style="color:green;">Address is focused on map</span>');
         
          //Focus viewport
          map.fitBounds(results[0].geometry.viewport);
  
          // Set Marker With tooltip        
          if (marker) {
            marker.setMap(null);
            marker = null;
          }
          var currenttitle = $('#edit-title').val();
          currenttitle = (currenttitle == '') ? 'Store Location' : currenttitle;
          var maptooltip_html = "<b>"+currenttitle+"</b><br>"+currentaddress;
          marker = createMarker(results[0].geometry.location, "storelocation", maptooltip_html);

          //Set Lat/Lng to hidden form field
          $('#edit-latitude').val(results[0].geometry.location.lat());
          $('#edit-longitude').val(results[0].geometry.location.lng());
  
        } else {
          $('.address-result').html('<span style="color:red;">Address cannot be focused</span>');
        }
      });

    }

  });

  $('.locate-storelocation').click(function(e) {

    e.preventDefault();
    var lat = $(this).attr('lat');
    var lng = $(this).attr('lng');
    var tooltip_html = $(this).attr('tooltip_html');
    if (marker) {
      marker.setMap(null);
      marker = null;
    }
    var latLng = new google.maps.LatLng(lat, lng);
    //$(window).scrollTop(200);
    goToByScroll('pwcs_storelocation_addnew');
    marker = createMarker(latLng, "storelocation", tooltip_html);

    map.setZoom(8);
    map.panTo(marker.position);

    //map.setCenter(marker_pos);
    
    //map.fitBounds(new google.maps.latLngBounds(marker_pos,marker_pos));
    
    //var current_bounds = map.getBounds();
    //var marker_pos = marker.getPosition();
    //if( !current_bounds.contains( marker_pos ) ){
    //  var new_bounds = current_bounds.extend( marker_pos );
    //  map.fitBounds( new_bounds );
    //}


    //map.setCenter(marker.position());
    //map.setZoom(10);
    //map.fitBounds(new google.maps.latLngBounds(marker_pos,marker_pos));

  });

  $('#autofind_location').change(function(e) {
    e.preventDefault();
    if($(this).attr("checked") == true) {
      $('.address-result').show();
    } else {
      $('.address-result').hide();
    }
    
  });

  //$('.storelocation-count-addnew-container .addnew_icon').click(function(e) {
  //  e.preventDefault();
  //  $($(this).attr('toggleid')).toggle('fast');
  //});

});

