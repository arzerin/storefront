// $Id: pwcs.js,v 1.1.2.2 2008/09/30 20:07:51 rasel kabir Exp $
$(document).ready(function() {

  //alert($(window).width());
  //alert($(document).width());
  
	//Email Harvest Protection for USJF (can be used by any merchant)
	//Example: <a href="#" class="email_mailto" ename="vpimada" eorg="aol" etype="c" >Mr. Vaughn Imada</a>
	$(".email_mailto").click(function(e){
		e.preventDefault();
		var ename = $(this).attr('ename');
		var eorg = $(this).attr('eorg');
		var etype = $(this).attr('etype');
		etype = (etype == "c") ? ".com" : ( (etype == "n") ? ".net" : ( (etype == "o") ? ".org" : "."+etype) );
		var enc_href = "mailto:"+ename+"@"+eorg+etype;
		window.location.href = enc_href;
	});
	
  // Product Details - Product Attr - Set Default
  var product_nid = $("body .node-type-product .addtocart-link").attr('product_id');
  var default_attribute = $("#pwcs_productdeatils_options_showall_"+product_nid).attr('default_attribute');
  if(typeof default_attribute != 'undefined') {
    pwcs_productdetails_set_select_combo(product_nid, default_attribute);
    $('#pwcs_productdeatils_options_chkavail_'+product_nid).click();
  }
  
  $('#header-group-inner').css('min-height', $('#header-group').height());

  $('.toggle_content').hide();
  $('.toggle_link').click(function(e) {
    e.preventDefault();
    $($(this).attr('toggle_content')).toggle('fast');
  });

  // Coach Profile
  $(".viewcoachprofile").click(function(e) {
    e.preventDefault();
    var coachid = $(this).attr('coachid');
    $('#coachprofile_tooltip_'+coachid).show(400, function(){
      $("*").click(function(e){
        $('.coachprofile_tooltip').hide();
      });
    });
  });

  //Flyout Menu: On hover Parent item selected
  $('ul.flyoutmenu ul').mouseover(function(){
    $(this).parent('li').children('a').addClass('hover');
  }).mouseout(function(){
    $(this).parent('li').children('a').removeClass('hover');
  });

  // Testimonial Rating Star
  $('.ratingstar').each(function(){
    var ratingamount = $(this).attr('ratingamount');
    var maxrating = $(this).attr('maxrating');
    $(this).html('<a id="rstar_1" class="rstar"></a>'
                +'<a id="rstar_2" class="rstar"></a>'
                +'<a id="rstar_3" class="rstar"></a>'
                +'<a id="rstar_4" class="rstar"></a>'
                +'<a id="rstar_5" class="rstar"></a>');
    var perstar_value = (maxrating / 5);
    var k = ratingamount;
    for (i=1; i<=5; i++) {
      var step_val = i * perstar_value;
      if(step_val <= ratingamount) {
        $(this).find('#rstar_'+i).addClass('full');
      } else if((step_val > ratingamount) & (k > 0)) {
        $(this).find('#rstar_'+i).addClass('half');
      } else {
        $(this).find('#rstar_'+i).addClass('empty');
      }
      k = k - perstar_value;
    }
  });

  // CP MENU
  //$('.cp_customer_menu').mouseover(function() {
  //  $('.cp_customer_menu a.mainbutton').addClass('active');
  //  $('#cp_submenu').show();
  //});
  //$('.cp_customer_menu').mouseout(function(){
  //  $('.cp_customer_menu a.mainbutton').removeClass('active');
  //  $('#cp_submenu').hide();
  //});

  // Common Popup For External URLs
  var window_height = $(window).height();
  $('a.pwcs-enduser-modaliframe').click(function(e) {
    e.preventDefault();

    var $this = $(this);
    var iframewidth = parseInt($(this).attr('iframewidth')?$(this).attr('iframewidth'):960);
    var iframeheight = parseInt($(this).attr('iframeheight')?$(this).attr('iframeheight'):(window_height - 180));

    //alert($(window).height() + ' - ' + window_height);
    var horizontalPadding = 5;
    var verticalPadding = 5;
       
    $('<iframe id="pwcs-enduser-modaliframe" class="pwcs-enduser-modaliframe pwcs-loading" src="' + this.href + '" />').dialog({
      title: ($this.attr('title')) ? $this.attr('title') : 'PWC Store - External Site',
      autoOpen: true,
      width: iframewidth+(horizontalPadding*2),
      height: iframeheight+(verticalPadding*2),
      modal: true,
      show: "blind",
      position: ['center', 30],
      //show: "blind",
      resizable: false,
      draggable: false,
      autoResize: true
      //close: function(event, ui) { window.location.reload(); },
      //overlay: { opacity: 0.7 },
      //buttons: {
      //  'Close': function() {
      //    $(this).dialog('close');
      //    window.location.reload();
      //  }
      //}
    }).width(iframewidth).height(iframeheight);
  });

  // Common modal box
  $(".modalpopup-content").hide();
  $(".modalpopup").click(function(e) {
    e.preventDefault();
    var modalpopup_title = ($(this).attr('title')) ? $(this).attr('title') : '';
    var modalpopup_content = $($(this).attr('modalpopup-content')).html();
    $('<div id=".modalpopup-modal" class="modalpopup-modal">'+modalpopup_content+'</div>').dialog({
      title: modalpopup_title,
      width: 600,
      height: 'auto',
      modal: true,
      show: "blind",
      resizable: false,
      draggable: false,
      autoResize: true,
      autoOpen: true,
      buttons: {
        'Ok': function() {
          $(this).dialog('close');
        }
      }
    });
    qty_discount_option_radio_click();
  });

  //Newsletter Defaultify
  $("#pwcs_productmodule_newlettersignup .field-container input").each(function(){
    var label = $(this).parent().children('label').text();
    $(this).defaultify(label);
  }); 
  $("#pwcs_productmodule_newlettersignup label").hide();

  //Secondary Newsletter Defaultify
  $("#block-pwcs-secondary_newlettersignup .field-container input").each(function(){
    var label = $(this).parent().children('label').text();
    $(this).defaultify(label);
  }); 
  $("#block-pwcs-secondary_newlettersignup label").hide();

  // Video POPUP
  $('.simplevideo_popup_link').click(function(e) {
    e.preventDefault();
    var video_src = $(this).attr('video_src');
    var video_title = $(this).attr('video_title');
    $('<div class="simplevideo_popup" style="display:none;"><iframe width="700" height="450" frameborder="0" allowfullscreen="" src="'+video_src+'"></iframe></div>').dialog({ 
      title: video_title,
      width: 730,
      autoOpen: true,
      show: "blind",
      hide: "blind",
      modal: true,
      resizable: false,
      draggable: false,
      autoResize: true,
      open: function(event, ui) { },
      overlay: { opacity: 1, background: "black" }
    });
  });

  //External URL In Iframe When called at page
  $('iframe.pwcs_iframe_page').hide();
  $('.pwcs_iframe_page').parent().append('<div class="pwcs-loading" style="height: 500px;"></div>');
  $('iframe.pwcs_iframe_page').load(function() {
    $('.pwcs_iframe_page').parent().children('.pwcs-loading').remove();
    $('iframe.pwcs_iframe_page').show();
    //this.style.height = this.contentWindow.document.body.offsetHeight + 'px';
  });

  $('#affiliate-forget-password-link').click(function(e) {
    e.preventDefault();
    $('#affiliate-forgetpassword-box').toggle('fast');
  });

  $loading_image = Drupal.settings.basePath+'sites/all/modules/pwcs/images/loading.gif';
  $('<img/>')[0].src = $loading_image;

  // Initializing cart dialog
  $("#cart-block-cart-pane").dialog({
    open: function(event, ui) { 
      $('.ui-widget-overlay').bind('click', function(){ 
        $("#cart-block-cart-pane").dialog('close'); 
      });
      //$('#cart-block-cart-pane').parent().css({position:"fixed"});
    },
    resizable: false,
    draggable: false,
    modal: true,
    width: 750,
    //height: 600,
    show: "blind",
    dialogClass: "cartpopup",
    position: ['center',50],
    autoOpen: false
//    buttons: {
//      'Check Out': function() {
//        var path = window.location.pathname;
//        if(path.substring(0,4) == '/fb/'){
//          window.top.location.href = Drupal.settings.basePath+'checkouturl';  
//        } else {
//          window.location.replace(Drupal.settings.basePath+'checkouturl');
//        }
//      },
//      'Continue Shopping': function() {
//        $(this).dialog('close');
//      },
//    }
  });
  

  // On click cart link
  $('.cart_link').click(function(e) {

    e.preventDefault();
    $("#cart-block-cart-pane").html('');
    $("#cart-block-cart-pane").addClass('pwcs-loading');
    $("#cart-block-cart-pane").dialog('open');

    var calling_url = $(this).attr('ajax_href');
      $.ajax({
      type: "POST",
      url: calling_url,
      //data: formdata,
      success: function(html_data){
        $("#cart-block-cart-pane").removeClass('pwcs-loading');
        $("#cart-block-cart-pane").html(html_data);
        pwcs_js_removefromcart();
        //pwcs_js_addtocart();
        pwcs_continueshopping_click();
      },
      error: function(){
        alert('Error!');
      }
    });

  });

  $('input#productdetails_addtocart_qty').change(function() {
    var product_id = $(this).attr('product_id');
    $('#addtocart-id-'+product_id).attr('addtocart_quantity',$(this).val());
  });

  $('input.checkbox_checkall').click(function() {
    var formid = $(this).parents('form').attr('id');
    var checked_status = this.checked;
    $("#"+formid+" input[type=checkbox]").each(function(){
      this.checked = checked_status;
    });
  });
  $("input.checkbox_checkall_products").click(function()  {
    var formid = $(this).parents('form').attr('id');
    var checked_status = this.checked;
    $("input[id=productnid]").each(function() {
      this.checked = checked_status;
    });    
  });  
  $("input.checkbox_checkall2").click(function()  {
    var formid = $(this).parents('form').attr('id');
    var checked_status = this.checked;
    $("input[id=activatesales]").each(function() {
      this.checked = checked_status;
    });    
  });

  $('input.checkbox_checkall_assign').click(function() {
    var formid = $(this).parents('form').attr('id');
    var checked_status = this.checked;
    $("#"+formid+" input[id=productassign]").each(function(){
      this.checked = checked_status;
    });
  });

  $('input.checkbox_checkall_unassign').click(function() {
    var formid = $(this).parents('form').attr('id');
    var checked_status = this.checked;
    $("#"+formid+" input[id=productunassign]").each(function(){
      this.checked = checked_status;
    });
  });
  $('input.checkbox_checkall_listproduct').click(function() {
    var formid = $(this).parents('form').attr('id');
    var checked_status = this.checked;
    $("#"+formid+" input[type=checkbox]").each(function(){
      this.checked = checked_status;
    });
  });
  $("input.checkbox_markallvisible").click(function()  {
    var formid = $(this).parents('form').attr('id');
    var checked_status = this.checked;
    $("input[id=makevisible]").each(function(){
      this.checked = checked_status;
    });    
  });  
  // Floating div position set (ie. cart link)
  var main_width = $('#main').width();
  var window_width = $(document).width();
  var pwcs_floating_region_width = $('#pwcs_floating_region').width();
  var position= ((window_width - main_width) /2)-pwcs_floating_region_width;
  //var position= ((window_width - main_width) /2);
  $('#pwcs_floating_region').css('right', position+'px');
  
  // product additional image hover START
  $('#productdetails_additionalimage .productimage img').each(function(){
    (new Image()).src = $(this).attr('alt');
  });    
  var default_img_src = $('#productdetails_defaultimage img').attr('src');
  var productdetails_defaultimage_height = $('#productdetails_defaultimage').height();
  $('#productdetails_defaultimage').height(productdetails_defaultimage_height);
  $('#productdetails_defaultimage img').removeAttr('height');
  $('#productdetails_additionalimage .productimage img').mouseover(function () {
    //var img_src = $(this).parent('a').attr('href'); //$(this).attr('alt');
    var img_src = $(this).attr('alt');
    $('#productdetails_defaultimage img').attr('src', img_src);
    $('#productdetails_defaultimage img').load(function () {
        //alert($('#productdetails_defaultimage img').height() +' - '+ productdetails_defaultimage_height);
      if( parseInt($('#productdetails_defaultimage img').height()) > parseInt($('#productdetails_defaultimage').height()) ) {
        $('#productdetails_defaultimage').height($('#productdetails_defaultimage img').height());
      }
    });
  }).mouseout(function(){
    $('#productdetails_defaultimage img').attr('src', default_img_src);
  });

  $("#productdetails_defaultimage a").click(function(e) {
    e.preventDefault();
  });  
  // product additional image hover END

  // Product Details Options Show All
  $('.pwcs_productdeatils_options_showall').click(function(e) {

    var calling_url = $(this).attr('ajax_url');
    var product_nid = $(this).attr('product_nid');
    var formdata = "product_nid="+product_nid+"&ajax=1";
    var current_selection = $(this).attr('current_selection');

    $('<div id="pwcs_productdeatils_options_showall_modal"></div>').dialog({
      title: "Products Options",
      autoOpen: true,
      width: 700,
      height: 400,
      modal: true,
      resizable: true,
      draggable: false,
      autoResize: true,
      open: function(event, ui) { 
        $('#pwcs_productdeatils_options_showall_modal').addClass('pwcs-loading');
        $.ajax({
          type: "POST",
          url: calling_url,
          data: formdata,
          success: function(html_data){
            $('#pwcs_productdeatils_options_showall_modal').removeClass('pwcs-loading');
            var data = Drupal.parseJson(html_data);
//            if(data.status == 'ok') {
//            }
//            if(data.status == 'notfound') {
//            }
            $('#pwcs_productdeatils_options_showall_modal').html(data.msgs);
            if(current_selection != ''){
              $('#pwcs_productdeatils_options_showall_modal input:radio[name=pwcs-productdetails-select-options]').filter("[value="+current_selection+"]").attr("checked","checked");
            }
            pwcs_filter_table_row('pwcs_productdeatils_alloptions_table');
          },
          error: function(){
            alert('Error!');
          }
        });
      },
      close: function(event, ui) { 
        $('#pwcs_productdeatils_options_showall_modal').remove();
      },
      overlay: { opacity: 0.7, background: "black" },
      buttons: {
        'Close': function() {
          $(this).dialog('close');
        },
        'Done': function() {
          // need to update hidden values on change
          var selected_options = $('#pwcs_productdeatils_options_showall_modal input:radio[name=pwcs-productdetails-select-options]:checked').val();
          if(typeof selected_options == 'undefined') {
            alert('No Options Selected');
          } else {
            $('#pwcs_productdeatils_options_showall_'+product_nid).attr('current_selection', selected_options);
            pwcs_productdetails_set_select_combo(product_nid, selected_options);
            $('.pwcs_productdeatils_options_main .each_option select').change();  
            $('#pwcs_productdeatils_options_chkavail_'+product_nid).click();
            $(this).dialog('close');
          }
        }
      }
    });
  });  

  // Product Details Options Check Availity
  $('.pwcs_productdeatils_options_chkavail').click(function(e) {
    
    var calling_url = $(this).attr('ajax_url');
    var product_nid = $(this).attr('product_nid');
    var realprice = $(this).attr('product_real_price');
    var realsku = $(this).attr('product_real_sku');

    

    var statusdiv = '#pwcs_productdeatils_options_main_'+product_nid+' .ajax_status';

    $(statusdiv).html('Please Wait..'); //.html('<div class="pwcs-small-loading"></div>');

    var idcount = $(this).attr('count');
    console.log('Option Count:'+idcount);
    var csv_options = '';
    for(var i=1; i<=idcount; i++){
      if($("#pwcs_productdeatils_select_"+product_nid+"_"+i).val() != '')
        csv_options += $("#pwcs_productdeatils_select_"+product_nid+"_"+i).val()+',';
         console.log('Inventory Items:'+$("#pwcs_productdeatils_select_"+product_nid+"_"+i).val());
    }
    csv_options = csv_options.substring(0, csv_options.length-1);
    var formdata = "csv_options="+csv_options+"&product_nid="+product_nid+"&ajax=1";  

    $.ajax({
      type: "POST",
      url: calling_url,
      async: false,
      data: formdata,
      success: function(html_data){
        var data = Drupal.parseJson(html_data);
        console.log(data);
        if(data.status == 'ok') {
          var newPrice = parseFloat(realprice) + parseFloat(data.affected_price);
          newPrice = CommaFormatted(newPrice);
          //var newPrice_curformat = (input/100).toFixed(2);
          //alert(newPrice_curformat);
          $('#productpriceamount_'+product_nid).text(newPrice);
          if(data.subsku != ''){
            $('#productskutext_'+product_nid).html(data.subsku);
          } else {
            $('#productskutext_'+product_nid).html(realsku);
          }
          $('a#addtocart-id-'+product_nid).attr('depended_attr_found', 1);
        }
        if(data.status == 'notfound') { 
          //$('#product_details #productdetails_price_amount').text(realprice);
          //$('#product_details .sku_value').html(realsku);
          $('#productpriceamount_'+product_nid).text(realprice);
          $('#productskutext_'+product_nid).html(realsku);
          $('a#addtocart-id-'+product_nid).attr('depended_attr_found', 0);
        }
        $(statusdiv).html(data.msgs);
      },
      error: function(){
        alert('Error!');
        $('#productpriceamount_'+product_nid).text(realprice);
        $('#productskutext_'+product_nid).html(realsku);
        $(statusdiv).html('Error!');
        $('a#addtocart-id-'+product_nid).attr('depended_attr_found', 0);
      }
    });
  });

  //add to cart
  pwcs_js_addtocart();

  // Initializing product review form dialog
  $('.productreview_addnew_span').show();
  $(".customer_reviews_form").dialog({
    open: function(event, ui) { 
        $('.ui-widget-overlay').bind('click', function(){ 
          $(".customer_reviews_form").dialog('close'); 
        });
      },
    resizable: false,
    draggable: false,
    modal: true,
    width: '600px',
    show: "blind",
    position: 'center',
    autoOpen: false,
    buttons: { }
  });
  // On click add new review link
  $('.productreview_addnew').click(function(e) {
    e.preventDefault();
    $(".customer_reviews_form").dialog('open');
  });

  //$("#pwcs_add_edit_products edit-salepricestartdate-dateformat").defaultify("Search...");
  //Search
  $("#edit-search-keyword").defaultify("Search...");

  //Jquery UI Modal for common use - RASEL KABIR
  $('.pwcs-modaldialog').click(function(e) {
      e.preventDefault();
      var $this = $(this);
      var modaldialogwidth = parseInt($this.attr('modaldialog-width') ? $this.attr('modaldialog-width') : 'auto');
      var modaldialogheight = parseInt($this.attr('modaldialog-height') ? $this.attr('modaldialog-height') : 'auto');
      var ajaxurl = ($this.attr('ajax_url')) ? $this.attr('ajax_url') : this.href ;
      var modaltitle = ($this.attr('title')) ? $this.attr('title') : 'PWC Store';
      var targettag = ($this.attr('targettag')) ? ' '+$this.attr('targettag') : '';

      $('<div class="pwcs-modaldialog-box pwcs-loading"></div>').load(ajaxurl+targettag, function(response, status, xhr) {
        if (status == "error") {
          $(this).addClass('error'); 
          $(this).html("Error : " + xhr.status + " " + xhr.statusText);
        } else {
          $(this).removeClass('pwcs-loading');
        }
      }).dialog({
        title: modaltitle,
        autoOpen: true,
        width: modaldialogwidth,
        height: modaldialogheight,
        modal: true,
        resizable: true,
        draggable: true,
        autoResize: true,
        //close: function(event, ui) { window.location.reload(); },
        overlay: { opacity: 0.7, background: "black" },
        buttons: {
//        'Done': function() {
//          $(this).dialog('close');
//          //window.location.reload();
//        },
        }
      });

  });

  //Comment Form Alter
  $coment_form_name_value = $('.customer_reviews_form form#comment-form input#edit-name').val();
  if($coment_form_name_value == 'Anonymous') {
    $('.customer_reviews_form form#comment-form input#edit-name').val('');
  }

  // Small Box Class Height Fix
  var normalBoxMaxHeight = Math.max.apply(null, $(".product_small_box_class").map(function (){
    return $(this).height();
  }).get());
  $('.product_small_box_class').each(function(){
    $(this).height(normalBoxMaxHeight);
  });

  // Normal Box Class Height Fix
  var normalBoxMaxHeight = Math.max.apply(null, $(".product_normal_box_class").map(function (){
    return $(this).height();
  }).get());
  $('.product_normal_box_class').each(function(){
    $(this).height(normalBoxMaxHeight);
  });

  // Normal Box Class 2 Height Fix
  var normalBoxMaxHeight = Math.max.apply(null, $(".product_normal2_box_class").map(function (){
    return $(this).height();
  }).get());
  $('.product_normal2_box_class').each(function(){
    $(this).height(normalBoxMaxHeight);
  });

  // Normal Box Class 3 Height Fix
  var normalBoxMaxHeight = Math.max.apply(null, $(".product_normal3_box_class").map(function (){
    return $(this).height();
  }).get());
  $('.product_normal3_box_class').each(function(){
    $(this).height(normalBoxMaxHeight);
  });

  $('.pwcs_productdeatils_options_main .each_option select').change(function() {
    
    var this_main = $(this).parents('.pwcs_productdeatils_options_main');// check
    var product_nid = this_main.find('.pwcs_productdeatils_options_chkavail').attr('product_nid');
    var product_optiontype = $("#addtocart-id-"+product_nid).attr('product_optiontype');
    var use_inventory = $("#addtocart-id-"+product_nid).attr('use_inventory');
    var product_attr = [];
    this_main.find('.each_option select').each(function(){
       $optionval = $(this).val();
       product_attr.push($optionval);
    });
    product_attr.sort();
    // Set selected_attr
    $("#addtocart-id-"+product_nid).attr('selected_attr', product_attr);
    
    // Set product_inventory
    if((product_optiontype == 'dependent_attribute') && (use_inventory == '2')) {
      var jsondata = this_main.find('.product_options_'+product_nid).html();
      var parsedata = Drupal.parseJson(jsondata);
      //console.log(parsedata);
      
      //Check if selected values are in json data array
      $.each(parsedata, function(i, item) {
        //alert(product_attr+'   '+item.attr_id);
        if(product_attr == item.attr_id) {
          var product_inventory = item.quantity;
          //$('#addtocart-id-'+product_nid).removeAttr('product_inventory');
          $('#addtocart-id-'+product_nid).attr('product_inventory', product_inventory);
        }
      });
    }
    
  });

});

function pwcs_js_addtocart() {
  
  // add to cart
  $('a[name=product-addtocart]').click(function(e) {
    e.preventDefault();
    
    var oneclickbuy = ($(this).attr('oneclickbuy')) ? $(this).attr('oneclickbuy') : 0;

    var calling_url = $(this).attr('ajax_addtocart_url');
    var product_id = $(this).attr('product_id');
    var product_link_id = $(this).attr('product_link_id');

    var addtocart_quantity = $(this).attr('addtocart_quantity');
    if(addtocart_quantity == undefined) { addtocart_quantity = '1'; }

    var product_inventory = $(this).attr('product_inventory');
    var use_inventory = $(this).attr('use_inventory');
    var current_cart_qty = $(this).attr('current_cart_qty');

    var recurring_profile_id = $('#pwcs_select_recurring_profile_'+product_id).val();
    if(recurring_profile_id == undefined) { recurring_profile_id = ''; }

    var product_optiontype = $(this).attr('product_optiontype');
    if(product_optiontype == 'dependent_attribute') {
      $('#pwcs_productdeatils_options_chkavail_'+product_id).click();
      if($(this).attr('depended_attr_found') == 0){
        //alert('Option Not Available');
        return false;
      }
    }
    
    //if(product_inventory != 'no') {
    //  if((parseInt(current_cart_qty) + parseInt(addtocart_quantity)) > parseInt(product_inventory)) {
    //      alert('Insufficient Product Inventory'); 
    //      return false;
    //  }
    //}
    
    if(oneclickbuy != 1) {
      $("#cart-block-cart-pane").html('');
      $("#cart-block-cart-pane").addClass('pwcs-loading');
      $("#cart-block-cart-pane").dialog('open');
    } else {
      $('<div class="pwcs-loading"></div>').dialog({
        title: 'Preparing for checkout..',
        autoOpen: true,
        modal: true,
        show: "blind",
        position: ['center', 30],
        resizable: false,
        draggable: false,
        autoResize: true
      });
    }
    
    var calling_url = $(this).attr('ajax_addtocart_url');
    var product_id = $(this).attr('product_id');
    var product_link_id = $(this).attr('product_link_id');

    var addtocart_quantity = $(this).attr('addtocart_quantity');
    if(addtocart_quantity == undefined) { addtocart_quantity = '1'; }

    var idcount = $('#pwcs_productdeatils_options_chkavail_'+product_id).attr('count');
    var csv_options = '';
    for(var i=1; i<=idcount; i++){
      if($('#pwcs_productdeatils_select_'+product_id+'_'+i).val() != '')
        csv_options += $('#pwcs_productdeatils_select_'+product_id+'_'+i).val()+',';
    }
    csv_options = csv_options.substring(0, csv_options.length-1);
    //csv_options = csv_options.split(",").sort().join(",");
    if(csv_options == undefined) { csv_options = ''; }
    
    var formdata = "recurring_profile="+recurring_profile_id+"&csv_options="+csv_options+"&product_id="+product_id+"&product_link_id="+product_link_id+"&addtocart_quantity="+addtocart_quantity+"&ajax=1&product_inventory="+product_inventory+"&use_inventory="+use_inventory+"&product_optiontype="+product_optiontype;

      $.ajax({
      type: "POST",
      url: calling_url,
      data: formdata,
      //async: false,
      success: function(data){
        //alert(data);
        var data = Drupal.parseJson(data);
        $("#cart-block-cart-pane").removeClass('pwcs-loading');
        if(data.response == 'added') {
          $('.carttotalitemcount').text(data.cartamount);
          $('.carttotalitemcount_totalqty').text(data.cartamount_totalqty);
          if(oneclickbuy == 1) {
            var path = window.location.pathname;
            if(path.substring(0,4) == '/fb/'){
              window.top.location.href = Drupal.settings.basePath+'checkouturl';  
            } else {
              window.location.replace(Drupal.settings.basePath+'checkouturl');
            }
            //$("#cart-block-cart-pane").dialog('close');
          } else {
            $("#cart-block-cart-pane").html(data.cartinfo);
            pwcs_js_removefromcart();
            pwcs_continueshopping_click();
          }
        } else if(data.response == 'warning') {
          $('.carttotalitemcount').text(data.cartamount);
          $('.carttotalitemcount_totalqty').text(data.cartamount_totalqty);
          $("#cart-block-cart-pane").html(data.cartinfo);
          pwcs_js_removefromcart();
          pwcs_continueshopping_click();
        } else {
          $("#cart-block-cart-pane").html(data.error_msgs);
          //$("#cart-block-cart-pane").dialog('close');
        }
      },
      error: function(){
        alert('Error!');
      }
    });
    //$("#cart-block-cart-pane").dialog('close');
  });
}


//remove from cart product-removefromcart
function pwcs_js_removefromcart() {
    
  $('a[name=product-removefromcart]').click(function(e) {
    e.preventDefault();
    var calling_url = $(this).attr('ajax_removefromcart_url');
    var pwc_orderitemid = $(this).attr('pwc_orderitemid');
    var formdata = "pwc_orderitemid="+pwc_orderitemid+"&ajax=1";
    var itemcount = $(".carttotalitemcount").html();
    var itemcount_totalqty = $(".carttotalitemcount_totalqty").html();

    var cartitem_buttons = $("#cart-block-cart-pane #cartitem-"+pwc_orderitemid+" .cartitem_buttons").html();
    $("#cart-block-cart-pane #cartitem-"+pwc_orderitemid+" .cartitem_buttons").html('<div class="pwcs-small-loading"></div>');

    $.ajax({
      type: "POST",
      url: calling_url,
      data: formdata,
      //async: false,
      success: function(data){
      var data = Drupal.parseJson(data);
        //alert(data.cart_item_remove);
        //alert(data.status);
        //alert(data.totalprice);
        if(data.response == 'removed') { 
        
          //alert(data.cart_amount+'-'+data.cart_totalqty);
          //$("#cart-block-cart-pane #cartitem-"+pwc_orderitemid+" .cartitem_buttons").html('<em>Item removed</em>');
          $("#cart-block-cart-pane .ajaxstatus").html(Drupal.t('Item removed'));
          $("#cart-block-cart-pane #cartitem-"+pwc_orderitemid).remove();
          $("#carttotalprice").html(data.totalprice);
          
          itemcount = parseInt(data.cart_amount);
          $(".carttotalitemcount").text(itemcount);
          itemcount_totalqty = parseInt(data.cart_totalqty);
          $(".carttotalitemcount_totalqty").text(itemcount_totalqty);
          if(itemcount == 0) {
            $("#cart-block-cart-pane .ajaxstatus").html(Drupal.t('All Items Removed'));
            //$("#cart-block-cart-pane").html(Drupal.t('All Items Removed'));
            $("#cart-block-cart-pane #pwcs_cartdetails").html(Drupal.t('All items have been removed from the cart.'));
            //$("#cart-block-cart-pane").dialog('close');
          }

        } else {
          $("#cart-block-cart-pane #cartitem-"+pwc_orderitemid+" .cartitem_buttons").html(cartitem_buttons);
          $("#cart-block-cart-pane .ajaxstatus").html('<em>Opps! Cannot be removed</em>');
        }
      },
      error: function(){
        alert('Error!');
      }
    });

  });
  
}

function pwcs_continueshopping_click() {
  $('a.continueshopping_button').click(function(e) {
    e.preventDefault();
    $("#cart-block-cart-pane").dialog('close');
  });
}

function pwcs_productdetails_set_select_combo(product_nid, attr_id) {

  var selected_options_array = new Array();
  selected_options_array = attr_id.split(",");
  var idcount = $('#pwcs_productdeatils_options_chkavail_'+product_nid).attr('count');
  for(var i=1; i<=idcount; i++){
    $("#pwcs_productdeatils_select_"+product_nid+"_"+i).val('');
  }
  for (a in selected_options_array ) {
    var attr_id = parseFloat(selected_options_array[a]);
    for(var i=1; i<=idcount; i++){
      if($("#pwcs_productdeatils_select_"+product_nid+"_"+i+" option[value='"+attr_id+"']").val() == attr_id) {
        $("#pwcs_productdeatils_select_"+product_nid+"_"+i).val(attr_id);
      }
    }
  }
}

function pwcs_filter_table_row(tableid){

  var filter_form = '<div class="filter_form" id="filter_form_'+tableid+'" style="padding: 5px 0 15px; text-align: center;">'
										+'<span>Filter:</span> <input type="text" name="filter-'+tableid+'" value="" size="50" />'
										+'</div>';
  $('#'+tableid).parent().prepend(filter_form);
  $('input[name=filter-'+tableid+']').focus().keyup(function() {
    var filterword = $(this).val();
    filterword = filterword.replace('(', '');
    filterword = filterword.replace(')', '');
    filterword = filterword.replace('"', '');
    filterword = filterword.replace('#', '');
    filterword = filterword.replace('$', '');
    //$('#testing').html(filterword);
    $('#'+tableid+' tbody tr:not(:contains("' + filterword + '"))').hide();
    $('#'+tableid+' tbody tr:contains("' + filterword + '")').show();
  });
}

function pwcs_filter_content(divid) {

  var filter_form = '<div class="filter-input">Filter : <input type="text" name="filter-'+divid+'" value="" size="50" /></div>';
  $(divid).parent().prepend(filter_form);
  $('input[name=filter-'+divid+']').focus().keyup(function() {
    var filterword = $(this).val();
    filterword = filterword.replace('(', '');
    filterword = filterword.replace(')', '');
    filterword = filterword.replace('"', '');
    filterword = filterword.replace('#', '');
    filterword = filterword.replace('$', '');

    $(divid+' div:not(:contains("' + filterword + '"))').hide();
    $(divid+' div:contains("' + filterword + '")').show();
  });
}

function pwcs_filter_content_customerlist_lys() {

  //$('#'+divid).parent().prepend(filter_form);
  $('#pwcs_crm_customerlist_lys_wrapper input[name=filter_crm_customerlist_lys]').focus().keyup(function() {
    var filterword = $(this).val();
    filterword = filterword.replace('(', '');
    filterword = filterword.replace(')', '');
    filterword = filterword.replace('"', '');
    filterword = filterword.replace('#', '');
    filterword = filterword.replace('$', '');

    //console.log(filterword);

    $('#pwcs_crm_customerlist_lys .lys_state:not(:contains("' + filterword + '"))').hide();
    $('#pwcs_crm_customerlist_lys .lys_state:contains("' + filterword + '")').show();
  });

}

jQuery.expr[':'].contains = function(a, i, m) {
  return jQuery(a).text().toUpperCase()
      .indexOf(m[3].toUpperCase()) >= 0;
};

function processPrint(){
  w=window.open('', "TrackHistoryData",
  "width=740,height=325,top=200,left=250,toolbars=no,scrollbars=yes,status=no,resizable=no");
  w.document.write($('h1').html()+'<br><br>'+$('.leftsection').html());
  w.print();
  w.close();
}

//function iframechangecss(){
  //alert("ddddddddd");
  //document.getElementById('affiliatesignup').contentWindow.document.getElementById('mainTable').style.display='none';
//}

function goToByScroll(id){
  $('html,body').animate({scrollTop: $("#"+id).offset().top},'slow');
}

function qty_discount_option_radio_click(){
  $('.qty_discount_option_radio_input').change(function(e) {
    e.preventDefault();
    var qty_amount = $(this).val();
    var product_nid = $(this).attr('product_nid');
    $('input#productdetails_addtocart_qty').val(qty_amount);
    $('#addtocart-id-'+product_nid).attr('addtocart_quantity',qty_amount);
  });
}

/*
* @package function
* @name CommaFormatted()
* Take a number in integer or floating number
* convert 2 dicimal point with comma seperate each 3-digit from right to left.
*/
function CommaFormatted(amount) {
  var delimiter = ","; // replace comma if desired
  amount = amount.toFixed(2);
  amount = new String(amount);
  var a = amount.split('.',2);
  var d = a[1];
  var i = parseInt(a[0]);

  if(isNaN(i)) { return ''; }
  var minus = '';
  if(i < 0) { minus = '-'; }
  i = Math.abs(i);
  var n = new String(i);
  var a = [];
  while(n.length > 3)
  {
    var nn = n.substr(n.length-3);
    a.unshift(nn);
    n = n.substr(0,n.length-3);
  }
  if(n.length > 0) { a.unshift(n); }
  n = a.join(delimiter);
  if(d.length < 1) { amount = n; }
  else { amount = n + '.' + d; }
  amount = minus + amount;
  return amount;
}

//function setiFrameHeight(var id = '') {
//  parent.document.getElementById(id).style.height = document['body'].offsetHeight + 'px';
//}
