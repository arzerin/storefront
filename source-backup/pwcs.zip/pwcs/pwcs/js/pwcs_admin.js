// $Id: pwcs.js,v 1.1.2.2 2008/09/30 20:07:51 rasel kabir Exp $

$(document).ready(function() {

  var window_height = $(window).height();

  $('.custom_page_search input[type=submit]').click(function(e) {
    e.preventDefault();
    var search_text = $(this).parent('.custom_page_search').find('input[name=search_text]').val();
    window.location.href = $(this).attr('actionurl') + '?search=' + search_text;
  });

  // Content Pages Tick Menu Hover To Remove
  $('.page_removefrommenu').mouseover(function() {
    $(this).find('.regular_icon').removeClass('tick');
    $(this).find('.regular_icon').addClass('remove');
  }).mouseout(function(){
    $(this).find('.regular_icon').addClass('tick');
    $(this).find('.regular_icon').removeClass('remove');
  });
  
  // Siteadmin Templates
  $(".template_section").each(function(e){
    $(this).find('.themelist_gridview_each').slice(4).hide();
    $(this).find('.showfour').hide();
  });

  $(".pwcs_theme_list .template_section .showmore a").click(function(e){
    e.preventDefault();
    $(this).parents('.template_section').find('.themelist_gridview_each').slideDown();
    $(this).parents('.template_section').find('.showfour').show();
    $(this).parents('.template_section').find('.showmore').hide();
  });

  $(".pwcs_theme_list .template_section .showfour a").click(function(e){
    e.preventDefault();
    $(this).parents('.template_section').find('.themelist_gridview_each').slice(4).slideUp();
    $(this).parents('.template_section').find('.showfour').hide();
    $(this).parents('.template_section').find('.showmore').show();
  });

  //Club Fee Visible/Hide Products
  $('#pwcs_product_list_assigned input.visible_on_site').click(function(e) {
    e.preventDefault();

    var chkArray = [];
    $("#pwcs_product_list_assigned .clubfee-product-select:checked").each(function() {
      chkArray.push($(this).val());
    });
    var selected = chkArray.join(',');
    if(selected.length > 1) {
      window.location.href = Drupal.settings.basePath + 'siteadmin/clubfeeproducts/' + 'visible_on_site/' + selected; //window.location.pathname
    } else {
      alert("No products has been selected");
    }
  });
  
  $('#pwcs_product_list_assigned input.hide_from_site').click(function(e) {
    e.preventDefault();

    var chkArray = [];
    $("#pwcs_product_list_assigned .clubfee-product-select:checked").each(function() {
      chkArray.push($(this).val());
    });
    var selected = chkArray.join(',');
    if(selected.length > 1) {
      window.location.href = Drupal.settings.basePath + 'siteadmin/clubfeeproducts/' + 'hide_from_site/' + selected; //window.location.pathname
    } else {
      alert("No products has been selected");
    }
  });

  // Storelocation Block Siteadmin Radio Show/Hide
  $('.siteadmin_storelocation_viewtype').hide();
  var storelocation_viewtype = $('.siteadmin_storelocation_viewtype_selection input[name=pwcs_storelocation_viewtype]:checked').val();
  $('#siteadmin_storelocation_viewtype_'+storelocation_viewtype).show();
  $('.siteadmin_storelocation_viewtype_selection input[name=pwcs_storelocation_viewtype]').change(function() {
    var selected_radio = $(this).val();
    $('.siteadmin_storelocation_viewtype').hide();
    $('#siteadmin_storelocation_viewtype_'+selected_radio).show();
  });

  // Popup Siteadmin Page
  $('.speciallink_toggle').click(function(e) {
    e.preventDefault();

    var hideclass = $(this).attr('hidecontent');
    $(hideclass).slideUp('fast');

    var showid = $(this).attr('showcontent');
    $(showid).slideDown('fast');
    
    $(this).parents('.specialmenu').find('.specialmenu_link').removeClass('active');
    $(this).addClass('active');
    
  });

  // Popup Siteadmin Page
  $('a.pwcs-siteadmin-popup').click(function(e) {
    e.preventDefault();

    var linktitle = $(this).attr('title');
    var iframewidth = parseInt($(this).attr('iframewidth')?$(this).attr('iframewidth'):960);
    var iframeheight = parseInt($(this).attr('iframeheight')?$(this).attr('iframeheight'):(window_height - 100));
    var horizontalPadding = 5;
    var verticalPadding = 5;
       
    $('<iframe id="pwcs-siteadmin-popup-content" class="pwcs-siteadmin-popup-content" src="' + this.href + '" />').dialog({
      title: (linktitle) ? linktitle : 'Site Admin',
      autoOpen: true,
      width: iframewidth+(horizontalPadding*2),
      height: iframeheight+(verticalPadding*2),
      modal: true,
      position: ['center', 30],
      //show: "blind",
      resizable: false,
      draggable: false,
      autoResize: true,
      load: function(event, ui) {
        $(this).css("height", $(this).contents().height() + "px");
      },
      //close: function(event, ui) { window.location.reload(); },
      overlay: { opacity: 0.7, background: "blue" }
      //buttons: {
      //  'Close': function() {
      //    $(this).dialog('close');
      //    window.location.reload();
      //  }
      //}
    }).width(iframewidth).height(iframeheight);
  });
  
  //setiFrameHeight('pwcs-siteadmin-popup-content');
  $('iframe.pwcs-siteadmin-popup-content').height('20');
  //$('#pwcs-external-site').parent().css('position', 'fixed');
 
  //$("iframe#pwcs-external-site #page #page-inner #header-group-wrapper").hide();
  //$("iframe#pwcs-external-site #page #page-inner #header-bottom-wrapper").hide();
  //$("iframe#pwcs-external-site #page #page-inner #breadcrumbs").hide();
  //$("iframe#pwcs-external-site #page #page-inner h1.title").hide();
  //$("iframe#pwcs-external-site #page #page-inner #footer-message-wrapper").hide();
  //$("iframe#pwcs-external-site #page #page-inner #main").removeClass("main");
  
  $(".add_new_listing").click(function(e) {
    e.preventDefault();
    $('.storelistings_addedit_form').slideToggle("slow");
  });

  $(".add_contentslide").click(function(e) {
    e.preventDefault();
    $('.contentslides_addedit_form').slideToggle("slow");
  });

  $(".search_product").click(function(e) {
    e.preventDefault();
    $('#pwcs_product_list_filter_box').slideToggle("slow");
  });

  $(".siteadmin_products_pricemanager .freeproduct-checkbox").change(function(e) {

     e.preventDefault(); 

     var nodeid = $(this).attr('nodeid');
     var standardprice = $('#product-price-'+nodeid).attr('currentvalue');
     var privateprice = $('#product-private-price-'+nodeid).attr('currentvalue');
     var wholesellerprice = $('#product-wholeseller-price-'+nodeid).attr('currentvalue');
     var distributorprice = $('#product-distributor-price-'+nodeid).attr('currentvalue');
     var activesalecheckbox = $('#product-activatesales-'+nodeid).attr('currentvalue');
     var saleprice = $('#product-salesprice-'+nodeid).attr('currentvalue');
     var salesstartdate = $('#pricemanager-salesstartdate-'+nodeid).attr('currentvalue');
     var salesenddate = $('#pricemanager-salesenddate-'+nodeid).attr('currentvalue'); 
     
     if($('#product-free-'+nodeid).is(':checked')) {
        $('#product-price-'+nodeid).val('0.00');
        $('#product-private-price-'+nodeid).val('0.00');
        $('#product-wholeseller-price-'+nodeid).val('0.00');
        $('#product-distributor-price-'+nodeid).val('0.00');
        $('#product-salesprice-'+nodeid).val('0.00');
        $('#product-activatesales-'+nodeid).removeAttr('checked');
        $('#pricemanager-salesstartdate-'+nodeid).val('');
        $('#pricemanager-salesenddate-'+nodeid).val('');
     } else {
        $('#product-price-'+nodeid).val(standardprice);
        $('#product-private-price-'+nodeid).val(privateprice);
        $('#product-wholeseller-price-'+nodeid).val(wholesellerprice);
        $('#product-distributor-price-'+nodeid).val(distributorprice);
        $('#product-activatesales-'+nodeid).attr('checked', activesalecheckbox);
        $('#product-salesprice-'+nodeid).val(saleprice);
        $('#pricemanager-salesstartdate-'+nodeid).val(salesstartdate);
        $('#pricemanager-salesenddate-'+nodeid).val(salesenddate);
     }
  });

  // Product Edit Tab Justified align - Start
  $(".product_edit_navigation_tab .tabrow").each(function(e){

    var row_width = $(this).width();
    //row_width = row_width - 2;  // it has 2px padding each
    var item_amount = $(this).find('a').size();
    var total_item_width = 0;
    $(this).find('a').each(function(e){
      total_item_width = total_item_width + $(this).width() + 4; //It has 2px margin and 2px border each padding is ignored as it will be set
    });
    
    var total_row_padding = row_width - total_item_width;
    var item_padding = (total_row_padding/item_amount)/2;
    var item_padding_floor = Math.floor(item_padding);
    var extra_space = total_row_padding - (item_padding_floor * item_amount * 2);
    //$(this).attr('extra_space', extra_space);

    $(this).find('a').css('padding-left', item_padding_floor+'px');
    $(this).find('a').css('padding-right', item_padding_floor+'px');
    
    if(extra_space > 1) {
      var last_item_width = $(this).find('a:last-child').width();
      last_item_width = (last_item_width + extra_space -1);
      $(this).find('a:last-child').css('width', last_item_width+'px');
    }
    
  });
  // Product Edit Tab Justified align - End
      

  // Common Toggle
  $('.togglecontent').hide();
  $('.togglelink').click(function (e) {
    e.preventDefault();
    var togglecontent = $(this).attr('togglecontent');
    $(togglecontent).slideToggle("slow");
  });
 
  $('select[name=fbcats_products_fbcatid_selection]').change(function(e) {
    e.preventDefault();
    window.location.href = $(this).attr('actionurl') + $(this).val();
  });

  $('select[name=pwcs_pager_dpp_input]').change(function() {
    var dppid = $(this).attr('dppid');
    var url = ($(this).attr('actionurl')) ? $(this).attr('actionurl') : window.location.pathname;
    url = url + '?dpp=' + $(this).val();
    window.location.href = url;
    //location.assign(url);
  });

  //Special only for Listing Assign/Unassign
  $('select[name=pwcs_pager_special_dpp_input]').change(function() {
    var url = ($(this).attr('actionurl')) ? $(this).attr('actionurl') : window.location.pathname;
    url = url + '?dpp_unassigned=' + $('#pwcs_pager_dpp_input_unassigned').val() + '&dpp_assigned='+$('#pwcs_pager_dpp_input_assigned').val();
    window.location.href = url;
  });

  //Manage Product - Sale price Activate
  //$('#siteadmin-productlist-form input.activatesales-checkbox').change(function() {
  //  var nid = $(this).attr('nid');
  //  if($(this).attr('checked') == true) {
  //    $('#product-salesprice-'+nid).parents('.salesprice-holder').addClass('active');
  //    $('#product-salesprice-'+nid).removeAttr("readonly");
  //    $('#product-salesprice-'+nid).focus();
  //    $('#product-price-'+nid).parents('.regularprice-holder').removeClass('active');
  //    $('#product-price-'+nid).attr("readonly", "readonly");
  //    $('#salesprice-salestag-'+nid).removeAttr("disabled");
  //  } else {
  //    $('#product-salesprice-'+nid).parents('.salesprice-holder').removeClass('active');
  //    $('#product-salesprice-'+nid).attr("readonly", "readonly");
  //    $('#product-price-'+nid).parents('.regularprice-holder').addClass('active');
  //    $('#product-price-'+nid).removeAttr("readonly");
  //    $('#product-price-'+nid).focus();
  //    $('#salesprice-salestag-'+nid).attr("disabled", "disabled");
  //  }
  //});

  $('#product_related_products_selection .form-checkboxes .form-item').mouseover(function() {
    if($(this).find('.option-spv-view').length) {
      $(this).find('.option-spv-view').show();
    } else {
      $(this).append('<div class="option-spv-view"><div class="option-spv-view-content"><div style="height:20px; width:20px;" class="pwcs-small-loading"></div></div>');
      var calling_url = $(this).find('.relatedproduct-item').attr('ajax_href');
      $(this).find('.option-spv-view-content').load(calling_url);
    }
  }).mouseout(function(){
    //$(this).find('.pwcs-small-loading').remove();
    $(this).find('.option-spv-view').hide();
  });

  $('form#block-admin-configure #edit-submit').val('Save');
  //$('form#block-admin-configure #edit-submit').after('<div class="clear"></div>');
  //$('form#menu-overview-form input#edit-submit').after('<div class="clear"></div>');


  //'#sitename_container '
  $('.toggleblock_checkbox input.form-checkbox').change(function() {
    $('.toggleblock_checkbox .enablecheckbox_tips').hide();
    if($(this).attr('checked') == true) {
      //$(this).parent().children('.enablecheckbox_tips').fadeIn('slow');
      $(this).parent().children('.enablecheckbox_tips')
        .fadeIn('slow')
        .animate({top: $(this).css('top'), bottom: $(this).css('bottom')}, 5000)
        .fadeOut('slow');
    } else {
      $(this).parent().children('.enablecheckbox_tips').hide();
    }
  });
  
  $('#menu_list_top form#menu-topmenu-form .warning').replaceWith('<span class=warning tabledrag-changed>*</span>Changes made in this table will not be saved until the Save Configuration button is clicked.');

  $('#field-slideshow-images-items table#field_slideshow_images_values .filefield-element .widget-edit').each(function(){
    $(this).children('div.form-item').children('label:first').html('Image Description or Hyper Link:');
    $(this).children('input.form-submit').val('Update With New Image');
  });

  //Added By Nafiz---For Image file size instruction in individual image upload section
  $('form#node-form #field-product-image-items table#field_product_image_values .filefield-element .widget-edit .description').append('<br>Optimal Image Size: 400px (height) X 400px (width)');

  // Slideshow Images
  $('#field-slideshow-images-items table#field_slideshow_images_values .filefield-element .widget-edit').each(function(){
    $(this).children('div.form-item').children('label:first').html('Image Description or Hyper Link:');
   // $(this).children('div.form-item:last').hide();
    $(this).children('input.form-submit').val('Update With New Image');
  });

  $('body#pid-siteadmin-stepbystep-step3 #pwcs_add_edit_products .addnew_product_buttons input#edit-submit').val('Complete My Website');

  // Product Edit Page - START
  $('#pwcs_add_edit_products #field-product-image-items').addClass('field-section');
  $('#pwcs_add_edit_products .field-section:first').slideDown('fast');
  $('#pwcs_add_edit_products a.pwc_store_tab:first').addClass('active');
  //$('#pwcs_add_edit_products .field-section:first').css('min-height',$('#pwcs_add_edit_products').height()+'px');

  $('#pwcs_add_edit_products a.pwc_store_tab').click(function(e) {
    e.preventDefault();
    $('#pwcs_add_edit_products .field-section').hide('fast');
    $('#pwcs_add_edit_products a.pwc_store_tab').removeClass('active');
    $(this).addClass('active');
    $($(this).attr('href')).slideDown('slow');
    //goToByScroll('pwcs_add_edit_products');
  });
  
  //$('#pwcs_add_edit_products .product-edit-tabs').append($('#product_buttons'));
  $('#pwcs_add_edit_products .product-edit-allbuttons').prepend($('#product_buttons'));
  
  //$("#pwcs_add_edit_products .standard").tabs();
  // Product Edit Page - END

  //$('#pwcs_add_edit_products #edit-teaser-wrapper iframe#edit-teaser_ifr').css('height', '200px');
  //$('#pwcs_add_edit_products #edit-body-wrapper iframe#edit-body_ifr').css('height', '300px');

  // On Change of Free Product Checkbox - Peoduct Edit
  var product_edit_price = $('#edit-price').val();
  var product_edit_saleprice = $('#edit-salesprice').val();
  var product_edit_price_private = $('#edit-price-private').val();
  var product_edit_price_wholeseller = $('#edit-price-wholeseller').val();
  var product_edit_price_distributor = $('#edit-price-distributor').val();
  var issalespriceactive = $('#edit-issalespriceactive').attr("checked");
  var product_edit_salepricestartdate_dateformat = $('#edit-salepricestartdate-dateformat').val();
  var product_edit_salepriceenddate_dateformat = $('#edit-salepriceenddate-dateformat').val(); 
  
  $('#pwcs_add_edit_products #edit-free-product').change(function() {
    if($(this).attr('checked') == true) {
      $('#edit-price').val('0.00');
      //$('#edit-price').attr("disabled", "disabled");
      $('#edit-salesprice').val('0.00');
      //$('#edit-salesprice').attr("disabled", "disabled");
      $('#edit-price-private').val('0.00');
      $('#edit-price-wholeseller').val('0.00');
      $('#edit-price-distributor').val('0.00');
      $('#edit-issalespriceactive').removeAttr('checked');
      $('#edit-salepricestartdate-dateformat').val('');
      $('#edit-salepriceenddate-dateformat').val('');
    } else {
      //$('#edit-price').removeAttr("disabled");
      //$('#edit-salesprice').removeAttr("disabled");
      $('#edit-issalespriceactive').attr("checked", issalespriceactive);;
      $('#edit-price').val(product_edit_price);
      $('#edit-salesprice').val(product_edit_saleprice);
      $('#edit-price-private').val(product_edit_price_private);
      $('#edit-price-wholeseller').val(product_edit_price_wholeseller);
      $('#edit-price-distributor').val(product_edit_price_distributor);
      $('#edit-salepricestartdate-dateformat').val(product_edit_salepricestartdate_dateformat);
      $('#edit-salepriceenddate-dateformat').val(product_edit_salepriceenddate_dateformat);
    }
  });

// For ebay free shipping cosr checking

  var ebay_shipping_cost             = $('#edit-pwcs-productfeed-ebay-shipping-cost-buyer').val();
  var ebay_shipping_additional_cost = $('#edit-pwcs-productfeed-ebay-shipping-addition-cost').val();
  $('#pwcs-siteadmin-productfeed-ebay-form #edit-pwcs-productfeed-ebay-shipping-free').change(function() {
    if($(this).attr('checked') == true) {
      $('#edit-pwcs-productfeed-ebay-shipping-cost-buyer').val('0.00');
      $('#edit-pwcs-productfeed-ebay-shipping-cost-buyer').attr("readonly", "readonly");
      $('#edit-pwcs-productfeed-ebay-shipping-addition-cost').val('0.00');
      $('#edit-pwcs-productfeed-ebay-shipping-addition-cost').attr("readonly", "readonly");
    } else {
      $('#edit-pwcs-productfeed-ebay-shipping-cost-buyer').removeAttr("readonly");
      $('#edit-pwcs-productfeed-ebay-shipping-addition-cost').removeAttr("readonly");
      $('#edit-pwcs-productfeed-ebay-shipping-cost-buyer').val(ebay_shipping_cost);
      $('#edit-pwcs-productfeed-ebay-shipping-addition-cost').val(ebay_shipping_additional_cost);
    }
  });
  
  $('a.pwcs-popup-iframe').click(function(e) {
    e.preventDefault();
        
    var linktitle =  $(this).attr('title');
    var iframewidth = parseInt($(this).attr('iframewidth')?$(this).attr('iframewidth'):960);
    var iframeheight = parseInt($(this).attr('iframeheight')?$(this).attr('iframeheight'):(window_height - 180));

    //alert($(window).height() + ' - ' + window_height);
    var horizontalPadding = 5;
    var verticalPadding = 5;
       
    $('<iframe id="pwcs-external-site" class="pwcs-external-site" src="' + this.href + '" />').dialog({
      title: (linktitle) ? linktitle : 'PWC Store - External Site',
      autoOpen: true,
      width: iframewidth+(horizontalPadding*2),
      height: iframeheight+(verticalPadding*2),
      modal: true,
      position: ['center', 30],
      //show: "blind",
      resizable: false,
      draggable: false,
      autoResize: true,
      //close: function(event, ui) { window.location.reload(); },
      overlay: { opacity: 0.7, background: "blue" },
      buttons: {
        'Close': function() {
          $(this).dialog('close');
          window.location.reload();
        }
      }
    }).width(iframewidth).height(iframeheight);
  });
  //$('#pwcs-external-site').parent().css('position', 'fixed');

  // Product edit product default image START
  var fid = $('#product_image_selection input[name=pwc_image_select]:checked').val();
  $('#product_image_selection .form-radios .form-item').removeClass('pwcs-item-selected');
  $("#product_image_selection #edit-pwc-image-select-"+fid+"-wrapper").addClass('pwcs-item-selected');

  $('#product_image_selection input[name=pwc_image_select]').change(function() {
    //var fid = $(this).val();
    var fid = $('#product_image_selection input[name=pwc_image_select]:checked').val();
    $('#product_image_selection .form-radios .form-item').removeClass('pwcs-item-selected');
    $("#product_image_selection #edit-pwc-image-select-"+fid+"-wrapper").addClass('pwcs-item-selected');
  });  
  // Product edit product default image END

  // Product edit related product START
  $('#product_related_products_selection .form-checkboxes input.form-checkbox').removeClass('pwcs-item-selected');
    $('#product_related_products_selection .form-checkboxes input.form-checkbox').each( function() {
    if($(this).attr('checked') == true) {
      var product_nid = $(this).val();
      $("#product_related_products_selection #edit-related-products-checkboxes-"+product_nid+"-wrapper").addClass('pwcs-item-selected');
    }
    });  
  $('#product_related_products_selection .form-checkboxes input.form-checkbox').change(function() {
    var product_nid = $(this).val();
    if($(this).attr('checked') == true) {
      $("#product_related_products_selection #edit-related-products-checkboxes-"+product_nid+"-wrapper").addClass('pwcs-item-selected');
    } else {
      $("#product_related_products_selection #edit-related-products-checkboxes-"+product_nid+"-wrapper").removeClass('pwcs-item-selected');
    }
  });  
  // Product edit related product END

//  $('#product_related_products_selection .form-checkboxes input.form-checkbox').removeClass('pwcs-item-selected');
//    $('.form-checkboxes input.form-checkbox').each( function() {
//    if($(this).attr('checked') == true) {
//      $(this).parent().addClass('pwcs-item-selected');
//    }
//  });  
//  $('.form-checkboxes input.form-checkbox').change(function() {
//    $(this).parent().toggleClass('pwcs-item-selected');
//  });  
  
  // Product Single View - SITEADMIN
  $('.psv_view').css('display', 'none');
  $('.showhidelink a').click(function (e) {
    e.preventDefault();
    var psv_key = $(this).attr('psv_key');
    $('#psv_template_'+psv_key).toggle();
  });

  // Filter/Search Products form - SITEADMIN

  $('.pwcs_search_toggle').click(function (e) {
    e.preventDefault();
    $('#pwcs_addproduct_manage_product').slideUp("slow");    
    $('.search-box-product').slideToggle("slow");
  });
  
  //General Search Toggle
  $('#pwcs_addproduct_manage_product').css('display', 'none');
  $('.pwcs_add_product_toggle').click(function (e) {
    e.preventDefault();
    $('.search-box-product').slideUp("slow");
    $('#pwcs_addproduct_manage_product').slideToggle("slow");
  });

  $('.search-toggle-holder a.search_product_icon').click(function (e) {
    e.preventDefault();
    $(this).parents('.search-toggle-holder').find('.search-box-product').slideToggle("slow");
  });
  $('.pwcs-page-managae-products-icon-holder a.search_assigned_product_icon').click(function (e) {
    e.preventDefault();
    $('.search-box-assigned-product').slideToggle("slow");
  });  

//  $('#facebook_faq_add').css('display', 'none');
//  $('.facebook-category-add-section a.add_fb_icon').click(function (e) {
//    e.preventDefault();
//    $('#facebook_faq_add').slideToggle("slow");
//  });
  
  $('#faq_item_add').css('display', 'none');
  $('#faq-container .faq-add-section a.add_faq').click(function (e) {
    e.preventDefault();
    $('#faq_item_add').slideToggle("slow");
  });


//  $('input#edit-pwcs-productmodule-livechat-enable').change(function (e) {
//    e.preventDefault();
//    $('#livechatinfo').slideToggle("slow");    
//  });
//  $('input#edit-pwcs-productmodule-clicktocall-enable').change(function (e) {
//    e.preventDefault();
//    $('#clicktocallinfo').slideToggle("slow");    
//  });
//  $('input#edit-pwcs-productmodule-ticketsystem-enable').change(function (e) {
//    e.preventDefault();
//    $('#ticketsysteminfo').slideToggle("slow");    
//  });


  $(".collapsiblebox .collapsiblebox-button").click(function(e) {
    e.preventDefault();
    $(this).toggleClass("collapsed");
    $(this).parent().children('.collapsiblebox-item').toggle('fast');
  });

  // Toggle Homepage Products - SITEADMIN
  $('.pwcs_plfs a.toggle-featured').click(function(e) {
    e.preventDefault();
    var calling_url = $(this).attr('href');
    var action = $(this).attr('action');
    var toaction = $(this).attr('toaction');
    var title = $(this).attr('title');
    var totitle = $(this).attr('totitle');

    $(this).attr('href', '');
    $(this).children(".pwcs-checkbox-icon").removeClass('pwcs-checkbox-checked');
    $(this).children(".pwcs-checkbox-icon").removeClass('pwcs-checkbox-notchecked');
    $(this).children(".pwcs-checkbox-icon").addClass('pwcs-small-loading');

    $.ajax({ type: "POST", url: calling_url });

    $(this).children(".pwcs-checkbox-icon").removeClass('pwcs-small-loading');

    if(action == 'removefeatured'){
      $(this).children(".pwcs-checkbox-icon").addClass('pwcs-checkbox-notchecked');
    }
    if(action == 'makeitfeatured'){
      $(this).children(".pwcs-checkbox-icon").addClass('pwcs-checkbox-checked');
    }
    var new_url = calling_url.replace(action, toaction);

    $(this).attr('href', new_url);
    $(this).attr('action', toaction);
    $(this).attr('toaction', action);
    $(this).attr('title', totitle);
    $(this).attr('totitle', title);
  });

  $("a#pwcs-header-banner-add-image").click(function(e) {
    e.preventDefault();
    window.open(Drupal.settings.basePath+'imce?app=myApp|sendto@headerImageFileHandler', '', 'width=760,height=560,resizable=1');
    //$("#pwcs-header-banner-add-image-preview").val(id);
  });

  $("a#pwcs-header-banner-add-image-remove").click(function(e) {
    e.preventDefault();
    var image_tag = ''; //'<img title="" alt="" src="">';
    $("#pwcs-header-banner-add-image-preview").html(image_tag);
    $("input[name=pwcs_headerbanner_image]").val(image_tag);
    //$("#pwcs-header-banner-add-image-preview").val(id);
  });

  $("#system-theme-settings .colorsettings .form-item .description").hide();
  $("#system-theme-settings .colorsettings .form-item").hover(function(e) {
    e.preventDefault();
    $("#system-theme-settings .colorsettings .form-item .description").hide();
    $(this).children('.description').show();
  });

  $(".siteadmin_dashboard .sd_item a.pwcs-commingsoon").click(function(e) {
    e.preventDefault();
  });

  var sd_item_inner_height = $('.siteadmin_dashboard .sd_item_inner').height();
  $('.siteadmin_dashboard .sd_item_inner .text').each( function() {
    var dashboard_text_padding = ( (sd_item_inner_height - $(this).height()) / 2 );
    $(this).css('padding-top', dashboard_text_padding);
  });

  var draggable_total_width = 0;
  $('.product-image-dragdrop .siteadmin-productimage-dragdrop-images #image_div div.draggable').each( function() {
    draggable_total_width = $(this).width() + draggable_total_width + 12; //(margin 3px*2 + padding 2px*2 + border 1px*2) = 12
  });
  $('.product-image-dragdrop .siteadmin-productimage-dragdrop-images #image_div').css('width', draggable_total_width+10+'px');

  pwcs_filter_imagecontent('.siteadmin-productimage-dragdrop-images #image_div');
      
  //$(".siteadmin_dashboard .sd_item a.pwcs-commingsoon").mouseover(function(e) {
  //  e.preventDefault();
  //  $(this).children('.sd_item_inner').append('<span class="comingsoon">Coming Soon..</span>');
  //}).mouseout(function () {
  //  $(this).children('.sd_item_inner').children('.comingsoon').remove();
  //});

  // SiteAdmin product edit check boxes - START
  $("#siteadmin-productlist-form #products-check-all").change(function(e) {
    var mode = this.checked;
    $("#siteadmin-productlist-form .product-main-select").each(function(){
      this.checked = mode;
    });
  });

  //select a product when any changes in that row
  $("#siteadmin-productlist-form input, #siteadmin-productlist-form select").not('#siteadmin-productlist-form input.product-main-select').change(function(){
    $(this).parents('tr.product-itemrow').find('.product-main-select').attr('checked',true);
  });

//  $('#siteadmin-productlist-form input.activatesales-checkbox').change(function() {
//    var nid = $(this).attr('nid');
//    alert(nid);
//    $(this).parents('tr').find('input#product-'+nid).attr('checked');
//  });
  // SiteAdmin product edit check boxes - END

  //$('#pwcs_product_list #image_div').stickyfloat({ duration: 400 });
  $(".call-comfirm-popup").click(function(e) {
    e.preventDefault();
    var themeid = $(this).attr('themeid');
    var title = ($(this).attr('title')) ? $(this).attr('title') : 'Confirmation';
    var message = '<div class="comfirm-popup-message">' + (($(this).attr('message'))? $(this).attr('message') : '<div class="comfirmmessage">Are You Sure?</div>') + '</div>';
    var href = $(this).attr('href');
    $('<div id="comfirm-popup-'+themeid+'" class="comfirm-popup">'+message+'</div>').dialog({
      title: title,
      autoOpen: true,
      width: 500,
      //height: 200,
      modal: true,
      resizable: false,
      draggable: false,
      autoResize: true,
      //close: function(event, ui) { window.location.reload(); },
      //overlay: { opacity: 0.5, background-color: "black" },
      buttons: {
        'Yes': function() {
          $(this).dialog('close');
          window.location.replace(href);
        },
        'Cancel': function() {
          $(this).dialog('close');
        }
      }
    });
  });
  
  //Added By Nafiz
  //For product tooltip info
  $('#gen_info_product_description').css('display', 'none');

  $(".popuptips-content").hide();
  $("a.pwcs_popuptips").click(function(e) {
    e.preventDefault();
    var notification_title = ($(this).attr('title')) ? $(this).attr('title') : 'Name Restrictions';
    var tips_content = $($(this).attr('popuptips-content')).html();
    $('<div id="popuptips-modal" class="popuptips-modal">'+tips_content+'</div>').dialog({
      title: notification_title,
      autoOpen: true,
      width: 600,
      height: 'auto',
      modal: true,
      resizable: false,
      draggable: false,
      autoResize: true
    });
  });
  
  
  
  $('#gen_info_image_size').css('display', 'none');
  $(".popuptips-content").hide();
  $("a.pwcs_popuptips_image").click(function(e) {
    e.preventDefault();
    var notification_title = ($(this).attr('title')) ? $(this).attr('title') : 'Image Tips';
    var tips_content = $($(this).attr('popuptips-content')).html();
    $('<div id="popuptips-modal" class="popuptips-modal">'+tips_content+'</div>').dialog({
      title: notification_title,
      autoOpen: true,
      width: 600,
      height: 'auto',
      modal: true,
      resizable: false,
      draggable: false,
      autoResize: true
    });
  });
  
  
  
    
  //For Power tool Module popup
  $('#powertools_instruction').css('display', 'none');

  $(".powertools-popuptips-content").hide();
  $("a.pwcs_popuptips_powertools").click(function(e) {
    e.preventDefault();
    var notification_title = ($(this).attr('title')) ? $(this).attr('title') : 'Power Tools Instructions';
    var tips_content = $($(this).attr('powertools-popuptips-content')).html();
    $('<div id="popuptips-modal" class="popuptips-modal">'+tips_content+'</div>').dialog({
        title: notification_title,
        autoOpen: true,
        width: 600,
        height: 'auto',
        modal: true,
        resizable: false,
        draggable: false,
        autoResize: true
    });
  });

  //Siteadmin Preview Tooltip
  $('.preview_screenshot_link').tooltip({
    track: true, 
    delay: 0, 
    showURL: false, 
    showBody: "", 
    fade: 250,
    extraClass: "preview_screenshot_content",
    bodyHandler: function() {
      return $(this).children('.screenshot').html(); 
    }
  });

  $('#pwcs_add_edit_products #product_basic #edit-title-wrapper.form-item input').after($('#pwcs_add_edit_products #product_basic #edit-title-wrapper.form-item label span.form-required'));
  $('#product_addnew #edit-title-wrapper.form-item input').after($('#product_addnew #edit-title-wrapper.form-item label span.form-required'));

  $('a#saleprice_startdate').click(function(e) {
    e.preventDefault();
    $($(this).attr('href')).val('');
  });
  $('a#saleprice_enddate').click(function(e) {
    e.preventDefault();
    $($(this).attr('href')).val('');
  });

  $('.showhideoptions .selectoption input[type=checkbox]').change(function(e) {
    e.preventDefault();
    if(this.checked == 1) {
      $(this).parents('.showhideoptions').find('.moreoptions').show();
    } else {
      $(this).parents('.showhideoptions').find('.moreoptions').hide();
    }
  });

  $('input.showhide_toggle_input').change(function(e) {
    e.preventDefault();
    var toggle_section = $(this).attr('showhide_toggle_section_id');
    if(this.checked == 1) {
      $(toggle_section).show();
    } else {
      $(toggle_section).hide();
    }
  });

  $('input#edit-pwcs-spv-addtocartlink').change(function(e) {
    e.preventDefault();
    if(this.checked == 1) {
      $('input#edit-pwcs-spv-oneclickbuy').attr('checked', false);
      $('input#edit-pwcs-spv-oneclickbuy').parents('.showhideoptions').find('.moreoptions').hide();
      $('input#edit-pwcs-productdetails-addtocartlink').attr('checked', true);
      $('input#edit-pwcs-productdetails-addtocartlink').parents('.showhideoptions').find('.moreoptions').show();
      $('input#edit-pwcs-productdetails-oneclickbuy').attr('checked', false);
      $('input#edit-pwcs-productdetails-oneclickbuy').parents('.showhideoptions').find('.moreoptions').hide();
    } else {
      $('input#edit-pwcs-spv-oneclickbuy').attr('checked', true);
      $('input#edit-pwcs-spv-oneclickbuy').parents('.showhideoptions').find('.moreoptions').show();
      $('input#edit-pwcs-productdetails-addtocartlink').attr('checked', false);
      $('input#edit-pwcs-productdetails-addtocartlink').parents('.showhideoptions').find('.moreoptions').hide();
      $('input#edit-pwcs-productdetails-oneclickbuy').attr('checked', true);
      $('input#edit-pwcs-productdetails-oneclickbuy').parents('.showhideoptions').find('.moreoptions').show();
    }
  });

  $('input#edit-pwcs-spv-oneclickbuy').change(function(e) {
    e.preventDefault();
    if(this.checked == 1) {
      $('input#edit-pwcs-spv-addtocartlink').attr('checked', false);
      $('input#edit-pwcs-spv-addtocartlink').parents('.showhideoptions').find('.moreoptions').hide();
      $('input#edit-pwcs-productdetails-addtocartlink').attr('checked', false);
      $('input#edit-pwcs-productdetails-addtocartlink').parents('.showhideoptions').find('.moreoptions').hide();
      $('input#edit-pwcs-productdetails-oneclickbuy').attr('checked', true);
      $('input#edit-pwcs-productdetails-oneclickbuy').parents('.showhideoptions').find('.moreoptions').show();
    } else {
      $('input#edit-pwcs-spv-addtocartlink').attr('checked', true);
      $('input#edit-pwcs-spv-addtocartlink').parents('.showhideoptions').find('.moreoptions').show();  
      $('input#edit-pwcs-productdetails-addtocartlink').attr('checked', true);
      $('input#edit-pwcs-productdetails-addtocartlink').parents('.showhideoptions').find('.moreoptions').show();
      $('input#edit-pwcs-productdetails-oneclickbuy').attr('checked', false);
      $('input#edit-pwcs-productdetails-oneclickbuy').parents('.showhideoptions').find('.moreoptions').hide();    
    }
    //$('input#edit-pwcs-spv-addtocartlink').change();
  });


  $('input#edit-pwcs-productdetails-addtocartlink').change(function(e) {
    e.preventDefault();
    if(this.checked == 1) {
      $('input#edit-pwcs-productdetails-oneclickbuy').attr('checked', false);
      $('input#edit-pwcs-productdetails-oneclickbuy').parents('.showhideoptions').find('.moreoptions').hide();
      $('input#edit-pwcs-spv-oneclickbuy').attr('checked', false);
      $('input#edit-pwcs-spv-oneclickbuy').parents('.showhideoptions').find('.moreoptions').hide();
      $('input#edit-pwcs-spv-addtocartlink').attr('checked', true);
      $('input#edit-pwcs-spv-addtocartlink').parents('.showhideoptions').find('.moreoptions').show();
            
    } else {
      $('input#edit-pwcs-productdetails-oneclickbuy').attr('checked', true);
      $('input#edit-pwcs-productdetails-oneclickbuy').parents('.showhideoptions').find('.moreoptions').show();
      
      $('input#edit-pwcs-spv-oneclickbuy').attr('checked', true);
      $('input#edit-pwcs-spv-oneclickbuy').parents('.showhideoptions').find('.moreoptions').show();
      $('input#edit-pwcs-spv-addtocartlink').attr('checked', false);
      $('input#edit-pwcs-spv-addtocartlink').parents('.showhideoptions').find('.moreoptions').hide();
    }
    //$('input#edit-pwcs-spv-oneclickbuy').change();
  });

  $('input#edit-pwcs-productdetails-oneclickbuy').change(function(e) {
    e.preventDefault();
    if(this.checked == 1) {
      $('input#edit-pwcs-productdetails-addtocartlink').attr('checked', false);
      $('input#edit-pwcs-productdetails-addtocartlink').parents('.showhideoptions').find('.moreoptions').hide();
      $('input#edit-pwcs-spv-oneclickbuy').attr('checked', true);
      $('input#edit-pwcs-spv-oneclickbuy').parents('.showhideoptions').find('.moreoptions').show();
      $('input#edit-pwcs-spv-addtocartlink').attr('checked', false);
      $('input#edit-pwcs-spv-addtocartlink').parents('.showhideoptions').find('.moreoptions').hide();
      
    } else {
      $('input#edit-pwcs-productdetails-addtocartlink').attr('checked', true);
      $('input#edit-pwcs-productdetails-addtocartlink').parents('.showhideoptions').find('.moreoptions').show();
      $('input#edit-pwcs-spv-oneclickbuy').attr('checked', false);
      $('input#edit-pwcs-spv-oneclickbuy').parents('.showhideoptions').find('.moreoptions').hide();
      $('input#edit-pwcs-spv-addtocartlink').attr('checked', true);
      $('input#edit-pwcs-spv-addtocartlink').parents('.showhideoptions').find('.moreoptions').show();
    }
    //$('input#edit-pwcs-spv-addtocartlink').change();
  });

  // Added by AR Zerin
  $(".draggable").draggable({
    revert: true,
    opacity: .75,
    containment: '.pwcs_table',
    cursor: 'move',
    cursorAt: { top: 35, left: 45 },
    helper: function(event) {
      return $('<div class="excerpt">' + $(this).children("div").html() + '</div>');
    },
    drag: function(event, ui) {
      $('.droppable').removeClass('drophighlight')
    }
  });
  $(".droppable").droppable({
    activeClass: 'dragactive',
    hoverClass: 'drophover',
    drop: function(event, ui) {
      $(this).addClass('drophighlight')
          .find('p')
          .html('' + ui.draggable.children("div").html()+ '');  
          //alert('Hello Pic Id:'+ui.draggable.children("div").attr("id"))
          //alert($(this).attr("id"));
          a='#productimageid-'+$(this).attr("id")
          b='productnid['+$(this).attr("id")+']'
          
          $("input[name="+b+"]").each(function()
          {
            this.checked = true;
          });    
          
          
          $(a).val(''+ui.draggable.children("div").attr("id"))
          //alert('Hidden value:'+$(a).val())
          //productimageid['.$result->nid.']
          //alert(ui.draggable.children('p').html());
    }
  });
  $(".droppable2").droppable({
    activeClass: 'dragactive',
    hoverClass: 'drophover',
    drop: function(event, ui) {
      $(this).addClass('drophighlight')
          .find('p')
          .html('' + ui.draggable.children("div").html()+ '');  
          a='#productimageid2-'+$(this).attr("id")
          b='productnid['+$(this).attr("id")+']'
          
          $("input[name="+b+"]").each(function()
          {
            this.checked = true;
          });    
          //alert('This function 2'+b);
          
          $(a).val(''+ui.draggable.children("div").attr("id"))
          //alert('Hidden value:'+$(a).val())
          //productimageid['.$result->nid.']
          //alert(ui.draggable.children('p').html());
    }
  });
  $(".droppable3").droppable({
    activeClass: 'dragactive',
    hoverClass: 'drophover',
    drop: function(event, ui) {
      $(this).addClass('drophighlight')
          .find('p')
          .html('' + ui.draggable.children("div").html()+ '');  
          a='#productimageid3-'+$(this).attr("id")
          b='productnid['+$(this).attr("id")+']'
          
          $("input[name="+b+"]").each(function()
          {
            this.checked = true;
          });    
          //alert('This function 2'+b);
          
          $(a).val(''+ui.draggable.children("div").attr("id"))
          //alert('Hidden value:'+$(a).val())
          //productimageid['.$result->nid.']
          //alert(ui.draggable.children('p').html());
    }
  });
  $(".droppable4").droppable({
    activeClass: 'dragactive',
    hoverClass: 'drophover',
    drop: function(event, ui) {
      $(this).addClass('drophighlight')
          .find('p')
          .html('' + ui.draggable.children("div").html()+ '');  
          a='#productimageid4-'+$(this).attr("id")
          b='productnid['+$(this).attr("id")+']'
          
          $("input[name="+b+"]").each(function()
          {
            this.checked = true;
          });    
          //alert('This function 2'+b);
          
          $(a).val(''+ui.draggable.children("div").attr("id"))
          //alert('Hidden value:'+$(a).val())
          //productimageid['.$result->nid.']
          //alert(ui.draggable.children('p').html());
    }
  });
  $(".droppable5").droppable({
    activeClass: 'dragactive',
    hoverClass: 'drophover',
    drop: function(event, ui) {
      $(this).addClass('drophighlight')
          .find('p')
          .html('' + ui.draggable.children("div").html()+ '');  
          a='#productimageid5-'+$(this).attr("id")
          b='productnid['+$(this).attr("id")+']'
          
          $("input[name="+b+"]").each(function()
          {
            this.checked = true;
          });    
          //alert('This function 2'+b);
          
          $(a).val(''+ui.draggable.children("div").attr("id"))
          //alert('Hidden value:'+$(a).val())
          //productimageid['.$result->nid.']
          //alert(ui.draggable.children('p').html());
    }
  });
  $(".droppable6").droppable({
    activeClass: 'dragactive',
    hoverClass: 'drophover',
    drop: function(event, ui) {
      $(this).addClass('drophighlight')
          .find('p')
          .html('' + ui.draggable.children("div").html()+ '');  
          a='#productimageid6-'+$(this).attr("id")
          b='productnid['+$(this).attr("id")+']'
          
          $("input[name="+b+"]").each(function()
          {
            this.checked = true;
          });    
          //alert('This function 2'+b);
          
          $(a).val(''+ui.draggable.children("div").attr("id"))
          //alert('Hidden value:'+$(a).val())
          //productimageid['.$result->nid.']
          //alert(ui.draggable.children('p').html());
    }
  });
  $(".droppable7").droppable({
    activeClass: 'dragactive',
    hoverClass: 'drophover',
    drop: function(event, ui) {
      $(this).addClass('drophighlight')
          .find('p')
          .html('' + ui.draggable.children("div").html()+ '');  
          a='#productimageid7-'+$(this).attr("id")
          b='productnid['+$(this).attr("id")+']'
          
          $("input[name="+b+"]").each(function()
          {
            this.checked = true;
          });    
          //alert('This function 2'+b);
          
          $(a).val(''+ui.draggable.children("div").attr("id"))
          //alert('Hidden value:'+$(a).val())
          //productimageid['.$result->nid.']
          //alert(ui.draggable.children('p').html());
    }
  });

  $.expr[':'].icontains = function(obj, index, meta, stack){
    return (obj.textContent || obj.innerText || jQuery(obj).text() || '').toLowerCase().indexOf(meta[3].toLowerCase()) >= 0;
  };
});

function headerImageFileHandler (file, win) {
  //alert(file.url);
  var image_tag = '<img title="" alt="" src="'+file.url+'">';
  $("#pwcs-header-banner-add-image-preview").html(image_tag);
  $("input[name=pwcs_headerbanner_image]").val(image_tag);
    win.close();//close IMCE
}

//function goToByScroll(id){
//  id = id.replace("link", "");
//  $('html,body').animate({ scrollTop: $("#"+id).offset().top}, 'slow');
//  return false;
//}

function pwcs_filter_imagecontent(divid){

  var filter_form = '<div class="filter-input">Filter : <input type="text" name="filter-'+divid+'" value="" size="50" /></div>';
  $(divid).parent().prepend(filter_form);

  $('input[name=filter-'+divid+']').focus().keyup(function() {
    var filterword = $(this).val()
    filterword = filterword.replace('(', '');
    filterword = filterword.replace(')', '');
    filterword = filterword.replace('"', '');
    filterword = filterword.replace('#', '');
    filterword = filterword.replace('$', '');
    //alert(filterword);
    //$('#testing').html(filterword);
    $(divid+' div:not(:icontains("' + filterword.toLowerCase() + '"))').hide();
    $(divid+' div:icontains("' + filterword.toLowerCase() + '")').show();
    $('.siteadmin-productimage-dragdrop-images #image_div .draggable-picname').animate({top: $(this).css('top'), bottom: $(this).css('bottom')}, 2000).fadeOut('slow'); //Added to hide drag and drop image name
    //$(divid+' div:not(:contains("' + filterword + '"))').hide();
    //$(divid+' div:contains("' + filterword + '")').show();
  });
}


function pwcs_getUrlParam(name) {
  return decodeURI(
    (RegExp(name + '=' + '(.+?)(&|$)').exec(location.search)||[,null])[1]
  );
} 
